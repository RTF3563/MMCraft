/////////////////////////////////////
// Complementary Shaders by EminGT //
/////////////////////////////////////

//Common//
#include "/lib/common.glsl"

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FRAGMENT_SHADER

flat in int mat;

in vec2 texCoord;
#ifdef GBUFFERS_COLORWHEEL_TRANSLUCENT
    vec2 lmCoord;
#else
    in vec2 lmCoord;
#endif
in vec2 signMidCoordPos;
flat in vec2 absMidCoordPos;

in vec3 playerPos;
in vec3 normal;
in vec3 viewVector;

in vec4 glColor;

#if WATER_STYLE >= 2 || RAIN_PUDDLES >= 1 && WATER_STYLE == 1 && !defined LOW_QUALITY_WATER_MATERIAL || defined GENERATED_NORMALS || defined CUSTOM_PBR
    flat in vec3 binormal, tangent;
#endif

#ifdef POM
    in vec4 vTexCoordAM;
#endif

#if ANISOTROPIC_FILTER > 0 && defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
    flat in vec2 midCoord;
    in vec4 spriteBounds;
#endif

#ifdef IRIS_FEATURE_FADE_VARIABLE
    flat in float chunkFade;
#endif

//Pipeline Constants//

//Common Variables//
vec3 upVec = normalize(gbufferModelView[1].xyz);
vec3 eastVec = normalize(gbufferModelView[0].xyz);
vec3 northVec = normalize(gbufferModelView[2].xyz);

vec3 sunVec = GetSunVector();

float NdotU = dot(normal, upVec);
float NdotUmax0 = max(NdotU, 0.0);
float SdotU = dot(sunVec, upVec);
float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;

#ifdef OVERWORLD
    vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#else
    vec3 lightVec = sunVec;
#endif

#if WATER_STYLE >= 2 || RAIN_PUDDLES >= 1 && WATER_STYLE == 1 && !defined LOW_QUALITY_WATER_MATERIAL || defined GENERATED_NORMALS || defined CUSTOM_PBR
    mat3 tbnMatrix = mat3(
        tangent.x, binormal.x, normal.x,
        tangent.y, binormal.y, normal.y,
        tangent.z, binormal.z, normal.z
    );
#endif

//Common Functions//
float GetLinearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

//Includes//
#include "/lib/util/dither.glsl"
#include "/lib/util/spaceConversion.glsl"
#include "/lib/lighting/mainLighting.glsl"
#include "/lib/atmospherics/fog/mainFog.glsl"
#include "/lib/materials/materialMethods/translucentTweaks.glsl"

#ifdef OVERWORLD
    #include "/lib/atmospherics/sky.glsl"
#endif

#if WATER_REFLECT_QUALITY >= 0
    #if defined SKY_EFFECT_REFLECTION_TRANSLUCENT && defined OVERWORLD
        #if AURORA_STYLE > 0
            #include "/lib/atmospherics/auroraBorealis.glsl"
        #endif

        #if NIGHT_NEBULAE == 1
            #include "/lib/atmospherics/nightNebula.glsl"
        #else
            #include "/lib/atmospherics/stars.glsl"
        #endif

        #ifdef VL_CLOUDS_ACTIVE
            #include "/lib/atmospherics/clouds/mainClouds.glsl"
        #endif
    #endif

    #include "/lib/materials/materialMethods/reflections.glsl"
#endif

#ifdef TAA
    #include "/lib/antialiasing/jitter.glsl"
#endif

#if defined GENERATED_NORMALS || defined COATED_TEXTURES || WATER_STYLE >= 2 || ANISOTROPIC_FILTER > 0 && defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
    #include "/lib/util/miplevel.glsl"
#endif

#ifdef GENERATED_NORMALS
    #include "/lib/materials/materialMethods/generatedNormals.glsl"
#endif

#if VIVID_WATER_MODE == 2 && WATER_STYLE >= 2
    #include "/lib/vivid/vividWater.glsl"
#endif

#if IPBR_EMISSIVE_MODE != 1
    #include "/lib/materials/materialMethods/customEmission.glsl"
#endif

#ifdef CUSTOM_PBR
    #include "/lib/materials/materialHandling/customMaterials.glsl"
#endif

#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/colorMultipliers.glsl"
#endif
#ifdef MOON_PHASE_INF_ATMOSPHERE
    #include "/lib/colors/moonPhaseInfluence.glsl"
#endif

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/misc/colorCodedPrograms.glsl"
#endif

#ifdef PORTAL_EDGE_EFFECT
    #include "/lib/voxelization/lightVoxelization.glsl"
#endif

#ifdef CONNECTED_GLASS_EFFECT
    #include "/lib/materials/materialMethods/connectedGlass.glsl"
#endif

#if ANISOTROPIC_FILTER > 0 && defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
    #include "/lib/materials/materialMethods/anisotropicFiltering.glsl"
#endif

//Program//
void main() {
    #if ANISOTROPIC_FILTER == 0 || !defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
        vec4 colorP = texture2D(tex, texCoord);
    #else
        vec4 colorP = textureAF(tex, texCoord);
    #endif

    #ifdef GBUFFERS_COLORWHEEL_TRANSLUCENT
        float ao;
        vec4 overlayColor;

        clrwl_computeFragment(colorP, colorP, lmCoord, ao, overlayColor);
        vec4 color = mix(colorP, overlayColor, overlayColor.a);
        lmCoord = clamp((lmCoord - 1.0 / 32.0) * 32.0 / 30.0, 0.0, 1.0);
    #else
        vec4 color = colorP * vec4(glColor.rgb, 1.0);
    #endif

    vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
    #ifdef TAA
        vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
    #else
        vec3 viewPos = ScreenToView(screenPos);
    #endif
    float lViewPos = length(viewPos);

    float dither = Bayer64(gl_FragCoord.xy);
    #ifdef TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #ifdef LIGHT_COLOR_MULTS
        lightColorMult = GetLightColorMult();
    #endif
    #ifdef ATM_COLOR_MULTS
        atmColorMult = GetAtmColorMult();
        sqrtAtmColorMult = sqrt(atmColorMult);
    #endif

    #ifdef VL_CLOUDS_ACTIVE
        float cloudLinearDepth = texelFetch(gaux2, texelCoord, 0).a;

        if (pow2(cloudLinearDepth + OSIEBCA * dither) * renderDistance < min(lViewPos, renderDistance)) discard;
    #endif

    float materialMask = 0.0;
    float vvWaterReflMod = 1.0; // MC-Vibrant-Shader: per-texel brightness of Vibrant Visuals water
    float vvWaterRough = 0.06;  // MC-Vibrant-Shader: per-texel roughness of Vibrant Visuals water

    vec3 nViewPos = normalize(viewPos);
    float VdotU = dot(nViewPos, upVec);
    float VdotS = dot(nViewPos, sunVec);
    float VdotN = dot(nViewPos, normal);

    // Materials
    vec4 translucentMult = vec4(1.0);
    bool noSmoothLighting = false, noDirectionalShading = false, translucentMultCalculated = false, noGeneratedNormals = false;
    int subsurfaceMode = 0;
    vec2 lmCoordM = lmCoord;
    float smoothnessG = 0.0, highlightMult = 1.0, reflectMult = 0.0, emission = 0.0;
    vec3 normalM = VdotN > 0.0 ? -normal : normal; // Inverted Iris Water Normal Workaround
    vec3 geoNormal = normalM;
    vec3 worldGeoNormal = normalize(ViewToPlayer(geoNormal * 10000.0));
    vec3 shadowMult = vec3(1.0);
    float fresnel = clamp(1.0 + dot(normalM, nViewPos), 0.0, 1.0);
    float fresnelM = pow3(fresnel);

    #include "/lib/materials/materialHandling/translucentMaterials.glsl"

    #if defined WATER_REFRACTION && SELECT_OUTLINE == 4
        int materialMaskInt = int(texelFetch(colortex6, texelCoord, 0).g * 255.1);
        if (materialMaskInt == 252) {
            materialMask = OSIEBCA * 252.0; // Versatile Selection Outline
        }
    #endif

    // Blending
    if (!translucentMultCalculated)
        translucentMult = vec4(mix(vec3(0.666), color.rgb * (1.0 - pow2(pow2(color.a))), color.a), 1.0);

    translucentMult.rgb = mix(translucentMult.rgb, vec3(1.0), min1(pow2(pow2(lViewPos / far))));

    // Lighting
    DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, dither,
               worldGeoNormal, lmCoordM, noSmoothLighting, noDirectionalShading, false,
               false, subsurfaceMode, smoothnessG, highlightMult, emission);

    // Reflections
    float skyLightFactor = GetSkyLightFactor(lmCoordM, shadowMult);
    #if WATER_REFLECT_QUALITY >= 0
        #ifdef LIGHT_COLOR_MULTS
            highlightColor *= lightColorMult;
        #endif
        #ifdef MOON_PHASE_INF_REFLECTION
            highlightColor *= pow2(moonPhaseInfluence);
        #endif

        fresnelM = (fresnelM * 0.85 + 0.15) * reflectMult;
        #if VIVID_WATER_MODE == 2
            // MC-Vibrant-Shader: Vibrant Visuals water reflectance - Fresnel on the per-texel water normal,
            // scaled per texel by the water texture (bright texels = bright reflection streaks)
            bool vvWater = mat == 32000;
            if (vvWater) fresnelM = min((0.05 + 0.95 * pow(fresnel, 2.5)) * reflectMult * (1.0 + 1.2 * (vvWaterReflMod - 1.0)), 1.0); // F0 ~0.05 (metalness 0.071)
        #endif

        vec4 reflection = GetReflection(normalM, viewPos.xyz, nViewPos, playerPos, lViewPos, -1.0,
                                        depthtex1, dither, skyLightFactor, fresnel,
                                        smoothnessG, geoNormal, color.rgb, shadowMult, highlightMult);
        #if VIVID_WATER_MODE == 2
            if (vvWater) {
                #ifdef OVERWORLD
                    // MC-Vibrant-Shader: rough texels see a blurred reflection lobe -> soft, sky-colored pixel streaks
                    if (isEyeInWater == 0) {
                        vec3 vvRefDir = reflect(nViewPos, normalM);
                        vec3 vvSoftSky = GetLowQualitySky(dot(vvRefDir, upVec) * 0.35, dot(vvRefDir, sunVec), dither, false, true); // cheaper blurred lobe
                        #ifdef ATM_COLOR_MULTS
                            vvSoftSky *= atmColorMult;
                        #endif
                        vvSoftSky = mix(reflection.rgb, vvSoftSky, skyLightFactor);
                        reflection.rgb = mix(reflection.rgb, vvSoftSky, clamp(vvWaterRough * 3.0, 0.0, 0.85));
                    }
                #endif
                reflection.rgb *= 0.72; // Vibrant Visuals water reflections are darker than the sky itself
                // MC-Vibrant-Shader: physically based blend like Vibrant Visuals - the reflection sits on top of the
                // (partly transparent) water instead of being faded out together with it:
                // result = F * reflection + (1 - F) * (alpha * water + (1 - alpha) * scene behind)
                float vvOutAlpha = fresnelM + (1.0 - fresnelM) * color.a;
                color.rgb = (fresnelM * reflection.rgb + (1.0 - fresnelM) * color.a * color.rgb) / max(vvOutAlpha, 0.0001);
                color.a = vvOutAlpha;
            } else
        #endif
        color.rgb = mix(color.rgb, reflection.rgb, fresnelM);

    #else
        fresnelM = 0.0;
        vec4 reflection = vec4(0.0);
    #endif
    ////

    #ifdef COLOR_CODED_PROGRAMS
        ColorCodeProgram(color, mat);
    #endif

    float skyFade = 0.0;
    float prevAlpha = color.a;
    color.a = 1.0;
    DoFog(color, skyFade, lViewPos, playerPos, VdotU, VdotS, dither, false, 0.0);
    float fogAlpha = color.a;
    color.a = prevAlpha * (1.0 - skyFade);

    #ifdef IRIS_FEATURE_FADE_VARIABLE
        skyLightFactor *= 0.5;
    #endif

    #ifdef DH_BLENDING
        float fog = max(length(playerPos.xz), abs(playerPos.y)) / far;
        fog = pow2(pow2(pow2(pow2(fog))));
        fog = exp(-3.0 * fog);
        color.a *= fog;
    #endif

    /* DRAWBUFFERS:03 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(1.0 - translucentMult.rgb, translucentMult.a);

    // supposed to be " #if defined WATER_REFRACTION || (WATER_REFLECT_QUALITY > 0 && WORLD_SPACE_REFLECTIONS_INTERNAL > 0) " but Optifine bad
    #if DETAIL_QUALITY >= 3 || (DETAIL_QUALITY >= 2 && VIVID_WATER_MODE == 2) || (WATER_REFLECT_QUALITY > 0 && WORLD_SPACE_REFLECTIONS > 0)
        /* DRAWBUFFERS:036 */
        gl_FragData[2] = vec4(1.0, materialMask, skyLightFactor, 1.0);

        #if WORLD_SPACE_REFLECTIONS > 0
            /* DRAWBUFFERS:03648 */
            gl_FragData[3] = vec4(mat3(gbufferModelViewInverse) * normalM, sqrt(fresnelM * color.a * fogAlpha));
            gl_FragData[4] = vec4(reflection.rgb * fresnelM * color.a * fogAlpha, reflection.a);
        #endif
    #elif WORLD_SPACE_REFLECTIONS > 0
        /* DRAWBUFFERS:0348 */
        gl_FragData[2] = vec4(mat3(gbufferModelViewInverse) * normalM, sqrt(fresnelM * color.a * fogAlpha));
        gl_FragData[3] = vec4(reflection.rgb * fresnelM * color.a * fogAlpha, reflection.a);
    #endif
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VERTEX_SHADER

flat out int mat;

out vec2 texCoord;
#ifdef GBUFFERS_COLORWHEEL_TRANSLUCENT
    vec2 lmCoord;
#else
    out vec2 lmCoord;
#endif
out vec2 signMidCoordPos;
flat out vec2 absMidCoordPos;

out vec3 playerPos;
out vec3 normal;
out vec3 viewVector;

out vec4 glColor;

#if WATER_STYLE >= 2 || RAIN_PUDDLES >= 1 && WATER_STYLE == 1 && !defined LOW_QUALITY_WATER_MATERIAL || defined GENERATED_NORMALS || defined CUSTOM_PBR
    flat out vec3 binormal, tangent;
#endif

#ifdef POM
    out vec4 vTexCoordAM;
#endif

#if ANISOTROPIC_FILTER > 0 && defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
    flat out vec2 midCoord;
    out vec4 spriteBounds;
#endif

#ifdef IRIS_FEATURE_FADE_VARIABLE
    flat out float chunkFade;
#endif

//Attributes//
attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 at_tangent;

//Common Variables//
#if WATER_STYLE >= 2 || RAIN_PUDDLES >= 1 && WATER_STYLE == 1 && !defined LOW_QUALITY_WATER_MATERIAL || defined GENERATED_NORMALS || defined CUSTOM_PBR
#else
    vec3 binormal;
    vec3 tangent;
#endif

//Common Functions//

//Includes//
#ifdef TAA
    #include "/lib/antialiasing/jitter.glsl"
#endif

#ifdef WAVING_WATER_VERTEX
    #include "/lib/materials/materialMethods/wavingBlocks.glsl"
#endif

//Program//
void main() {
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = GetLightMapCoordinates();

    glColor = gl_Color;

    mat = int(mc_Entity.x + 0.5);

    normal = normalize(gl_NormalMatrix * gl_Normal);

    vec3 rawBinormal = gl_NormalMatrix * cross(at_tangent.xyz, gl_Normal.xyz) * at_tangent.w;
    binormal = rawBinormal * inversesqrt(max(dot(rawBinormal, rawBinormal), 1e-8));
    vec3 rawTangent = gl_NormalMatrix * at_tangent.xyz;
    tangent = rawTangent * inversesqrt(max(dot(rawTangent, rawTangent), 1e-8));

    mat3 tbnMatrix = mat3(
        tangent.x, binormal.x, normal.x,
        tangent.y, binormal.y, normal.y,
        tangent.z, binormal.z, normal.z
    );

    viewVector = tbnMatrix * (gl_ModelViewMatrix * gl_Vertex).xyz;

    #if ANISOTROPIC_FILTER == 0 || !defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
        vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
    #else
        midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
    #endif
    vec2 texMinMidCoord = texCoord - midCoord;
    signMidCoordPos = sign(texMinMidCoord);
    absMidCoordPos  = abs(texMinMidCoord);

    #ifdef POM
        vTexCoordAM.zw  = abs(texMinMidCoord) * 2;
        vTexCoordAM.xy  = min(texCoord, midCoord - texMinMidCoord);
    #endif

    vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    playerPos = position.xyz;

    #ifdef WAVING_WATER_VERTEX
        DoWave(position.xyz, mat);
    #endif

    gl_Position = gl_ProjectionMatrix * gbufferModelView * position;

    #ifdef TAA
        gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
    #endif

    #if ANISOTROPIC_FILTER > 0 && defined ANISOTROPIC_FILTER_ON_TRANSLUCENTS
        vec3 upVec = normalize(gbufferModelView[1].xyz);
        if (mc_Entity.y > 0.5 && dot(normal, upVec) < 0.999) absMidCoordPos = vec2(0.0); // Fix257062

        vec2 spriteRadius = abs(texCoord - mc_midTexCoord.xy);
        vec2 bottomLeft = mc_midTexCoord.xy - spriteRadius;
        vec2 topRight = mc_midTexCoord.xy + spriteRadius;
        spriteBounds = vec4(bottomLeft, topRight);
    #endif

    #ifdef IRIS_FEATURE_FADE_VARIABLE
        chunkFade = mc_chunkFade;
    #endif

    #if MC_VERSION >= 260100
        if (mat == 10049) mat = 32001; // Cauldron Water
    #endif
}

#endif
