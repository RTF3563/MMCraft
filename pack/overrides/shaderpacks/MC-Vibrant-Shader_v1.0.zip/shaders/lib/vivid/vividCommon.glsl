/*---------------------------------------------------------------------
    MC-Vibrant-Shader - shared helpers
    Bedrock "Vibrant Visuals" inspired additions on top of
    Complementary Reimagined by EminGT (www.complementary.dev)
---------------------------------------------------------------------*/
#ifndef INCLUDE_VIVID_COMMON
    #define INCLUDE_VIVID_COMMON

    // Same luma weights as GetLuminance() so all MC-Vibrant-Shader effects stay consistent with the base pack
    #define VV_LUMA vec3(0.299, 0.587, 0.114)

    vec3 vvSaturate(vec3 c, float s) {
        float l = dot(c, VV_LUMA);
        return max(mix(vec3(l), c, s), vec3(0.0));
    }

    // Hue rotation around the gray axis (positive angle: red -> green -> blue)
    vec3 vvHueRotate(vec3 c, float angle) {
        const vec3 k = vec3(0.57735027);
        float ca = cos(angle);
        float sa = sin(angle);
        return c * ca + cross(k, c) * sa + k * dot(k, c) * (1.0 - ca);
    }

    // RGB -> HSV (hue in 0..1), branchless
    vec3 vvRGBtoHSV(vec3 c) {
        vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
        vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
        vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
        float d = q.x - min(q.w, q.y);
        const float e = 1.0e-10;
        return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
    }

    // Smooth weight for hues close to "center" (all values in 0..1 hue space, wraps around)
    float vvHueBand(float hue, float center, float width) {
        float d = abs(fract(hue - center + 0.5) - 0.5);
        return 1.0 - smoothstep(0.0, width, d);
    }

    // Water tint. mode 1: Vivid (more saturated Java colors)
    //             mode 2: Vibrant Visuals (deeper teal-navy body color; only blue-ish hues are rotated,
    //                     so swamp / warm ocean waters keep their identity)
    vec3 vvWaterColor(vec3 c, int mode) {
        vec3 hsv = vvRGBtoHSV(c);
        float blueBand = vvHueBand(hsv.x, 0.61, 0.10) * smoothstep(0.05, 0.25, hsv.y);
        if (mode >= 2) {
            c = vvHueRotate(c, -0.05 * blueBand);
            c = vvSaturate(c, 1.0 + 0.25 * (0.5 + 0.5 * blueBand));
            c *= 0.80;
        } else {
            c = vvSaturate(c, 1.0 + 0.22 * (0.5 + 0.5 * blueBand));
        }
        return max(c, vec3(0.0));
    }

#endif //INCLUDE_VIVID_COMMON
