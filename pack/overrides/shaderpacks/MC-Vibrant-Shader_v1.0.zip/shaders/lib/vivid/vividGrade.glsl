/*---------------------------------------------------------------------
    MC-Vibrant-Shader - Vivid Color Grade
    Display-referred (post tonemap) grade that gives the clean, punchy
    "Vibrant Visuals" look: smart vibrance, lush foliage, deep blues
    and a gentle warm-highlight / cool-shadow split tone.
---------------------------------------------------------------------*/
#ifdef VIVID_GRADE
    void DoVividGrade(inout vec3 color) {
        color = clamp(color, vec3(0.0), vec3(1.0));

        vec3 hsv = vvRGBtoHSV(color);
        float lum = dot(color, VV_LUMA);

        // Protect near-black and near-white pixels from color shifts
        float midMask = smoothstep(0.015, 0.12, lum) * (1.0 - smoothstep(0.88, 1.0, lum));

        float warmBand    = vvHueBand(hsv.x, 0.075, 0.07); // torch light, lava, skin
        float foliageBand = vvHueBand(hsv.x, 0.27, 0.12);  // grass, leaves
        float blueBand    = vvHueBand(hsv.x, 0.585, 0.10); // sky, water

        float waterMult = isEyeInWater == 1 ? 0.5 : 1.0; // Underwater is already very blue

        // 1) Smart vibrance: lifts dull colors much more than already-saturated ones
        float vibrance = VIVID_VIBRANCE * 0.01 * pow2(1.0 - hsv.y) * midMask * (1.0 - 0.6 * warmBand);
        color = vvSaturate(color, 1.0 + 1.4 * vibrance);

        // 2) Lush foliage: richer greens nudged slightly toward a sunny yellow-green
        float foliage = VIVID_FOLIAGE * 0.01 * foliageBand * midMask * smoothstep(0.05, 0.25, hsv.y);
        if (foliage > 0.001) color = vvHueRotate(color, -0.10 * foliage);
        color = vvSaturate(color, 1.0 + 0.40 * foliage);
        color *= 1.0 + 0.05 * foliage;

        // 3) Deep blues: clearer skies and water
        float blue = VIVID_BLUE * 0.01 * blueBand * midMask * waterMult * smoothstep(0.05, 0.20, hsv.y);
        color = vvSaturate(color, 1.0 + 0.35 * blue);
        color *= 1.0 - 0.04 * blue;

        // 4) Highlight roll-off: brings back color in near-white haze instead of a washed-out horizon
        #if VIVID_HIGHLIGHT > 0
            lum = dot(color, VV_LUMA);
            float hlRoll = smoothstep(0.72, 1.0, lum) * VIVID_HIGHLIGHT * 0.01;
            color = vvSaturate(color, 1.0 + 0.45 * hlRoll);
            color *= 1.0 - 0.10 * hlRoll;
        #endif

        // 5) Split tone: warm sunlit highlights, cool shade (luminance-neutral tints)
        #if VIVID_SPLIT_TONE > 0
            lum = dot(color, VV_LUMA);
            const vec3 coolTint = vec3(-0.30, 0.02, 0.55);
            const vec3 warmTint = vec3(0.45, 0.12, -0.55);
            vec3 coolTintN = coolTint - dot(coolTint, VV_LUMA);
            vec3 warmTintN = warmTint - dot(warmTint, VV_LUMA);
            float shadowW = (1.0 - smoothstep(0.05, 0.45, lum)) * smoothstep(0.0, 0.06, lum);
            shadowW *= 1.0 - warmBand; // keep torch / lava lit areas warm
            float highW = smoothstep(0.50, 0.95, lum);
            color += VIVID_SPLIT_TONE * 0.01 * 0.06 * (shadowW * coolTintN * waterMult + highW * warmTintN) * min(lum * 4.0, 1.0);
        #endif

        color = clamp(color, vec3(0.0), vec3(1.0));
    }
#endif
