/*---------------------------------------------------------------------
    MC-Vibrant-Shader - Vibrant Visuals water surface
    Matches Bedrock's vanilla Vibrant Visuals water material
    (textures/blocks/water_still_grey texture set in Mojang's bedrock-samples):
      - normal map  = slope of the grey water texture (correlation 0.79 / 0.93, scale ~1.05)
      - roughness   = -0.396 + 0.748 * brightness   (correlation 1.00, range 0.06 .. 0.34)
      - metalness   = 0.071 (constant)  -> F0 ~ 0.05
    So every texel is a tiny tilted mirror: dark texels are sharp mirrors, bright texels are
    rough and show a soft sky-colored reflection -> the pixel streaks of Vibrant Visuals.
    Used only in gbuffers_water (needs the block atlas).
---------------------------------------------------------------------*/
#ifndef INCLUDE_VV_WATER
    #define INCLUDE_VV_WATER

    float vvWaterTexelHeight(ivec2 texel) {
        return dot(texelFetch(tex, texel, 0).rgb, vec3(0.299, 0.587, 0.114));
    }

    // xy: tangent-space normal tilt, z: albedo/reflection modulation, w: roughness
    vec4 GetVVWaterSurface() {
        if (absMidCoordPos.x <= 0.0 || absMidCoordPos.y <= 0.0) return vec4(0.0, 0.0, 1.0, 0.06);

        vec2 atlas = vec2(atlasSize);
        vec2 spriteMinUV = texCoord - signMidCoordPos * absMidCoordPos - absMidCoordPos;
        ivec2 spriteMin = ivec2(floor(spriteMinUV * atlas + 0.5));
        ivec2 spriteSize = max(ivec2(floor(absMidCoordPos * 2.0 * atlas + 0.5)), ivec2(2));

        ivec2 local = clamp(ivec2(floor(texCoord * atlas)) - spriteMin, ivec2(0), spriteSize - 1);

        // Neighbours wrap inside the sprite (the water texture tiles seamlessly)
        ivec2 lx = ivec2((local.x - 1 + spriteSize.x) % spriteSize.x, local.y);
        ivec2 rx = ivec2((local.x + 1) % spriteSize.x, local.y);
        ivec2 dy = ivec2(local.x, (local.y - 1 + spriteSize.y) % spriteSize.y);
        ivec2 uy = ivec2(local.x, (local.y + 1) % spriteSize.y);

        float hC = vvWaterTexelHeight(spriteMin + local);
        float hL = vvWaterTexelHeight(spriteMin + lx);
        float hR = vvWaterTexelHeight(spriteMin + rx);
        float hD = vvWaterTexelHeight(spriteMin + dy);
        float hU = vvWaterTexelHeight(spriteMin + uy);

        // Slope of the texture brightness -> per-texel normal (constant across the texel = pixelated)
        vec2 slope = vec2(hR - hL, hU - hD) * 0.5;
        // Mojang's map is ~1.05x the slope; 2.0x matches the streak contrast of in-game Vibrant Visuals screenshots
        vec2 tilt = clamp(-slope * 2.0, vec2(-0.35), vec2(0.35));

        // Texels brighter than their neighbourhood are slightly brighter
        float hAvg = (hC + hL + hR + hD + hU) * 0.2;
        float rel = (hC - hAvg) / max(hAvg, 0.05);
        float brightMod = clamp(1.0 + 1.2 * rel, 0.7, 1.45);

        // Vibrant Visuals roughness from brightness
        float rough = clamp(-0.396 + 0.748 * hC, 0.06, 0.34);

        return vec4(tilt, brightMod, rough);
    }
#endif
