/*---------------------------------------------------------------------
    MC-Vibrant-Shader - Clarity
    Mid-frequency local contrast (larger radius than Image Sharpening)
    for the crisp, "pixel-clean" Bedrock look. Works on luminance only
    so it doesn't create color fringes, and is limited in strength to
    avoid halos around outlines.
---------------------------------------------------------------------*/
#if VIVID_CLARITY > 0
    void DoVividClarity(inout vec3 color, vec2 coord) {
        vec2 px = 2.5 / vec2(viewWidth, viewHeight);
        vec2 pxD = px * 0.85;

        float lumC = dot(color, VV_LUMA);
        float lumB = dot(texture2D(colortex3, coord + vec2( pxD.x,  pxD.y)).rgb, VV_LUMA)
                   + dot(texture2D(colortex3, coord + vec2(-pxD.x,  pxD.y)).rgb, VV_LUMA)
                   + dot(texture2D(colortex3, coord + vec2( pxD.x, -pxD.y)).rgb, VV_LUMA)
                   + dot(texture2D(colortex3, coord + vec2(-pxD.x, -pxD.y)).rgb, VV_LUMA);
        lumB *= 0.25; // 4 taps (performance); bilinear filtering between texels keeps it smooth

        float detail = clamp(lumC - lumB, -0.08, 0.08);
        float midtones = clamp(4.0 * lumC * (1.0 - lumC), 0.0, 1.0);
        float k = VIVID_CLARITY * 0.016 * midtones;

        float newLum = max(lumC + detail * k, 0.0);
        color *= clamp(newLum / max(lumC, 0.001), 0.6, 1.5);
    }
#endif
