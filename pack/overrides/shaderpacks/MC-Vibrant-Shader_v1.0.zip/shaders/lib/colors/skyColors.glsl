#ifndef INCLUDE_SKY_COLORS
    #define INCLUDE_SKY_COLORS

    #ifdef OVERWORLD
        // MC-Vibrant-Shader: Vibrant Visuals sky palette (from Bedrock's vanilla atmospherics.json keyframes):
        // muted steel-blue zenith, grey-white horizon, peach sunset band, lavender anti-solar sky, blue-grey night.
        // Luminance comes from Complementary, hue/saturation from Vibrant Visuals. Faded out during rain.
        // Only builtins + object-like macros so it is safe inside global initializers.
        #ifdef VIVID_SKY
            #define VV_SKY_K (min(VIVID_SKY_I * 0.01 * VV_K, 1.0) * (1.0 - rainFactor))
        #else
            #define VV_SKY_K 0.0
        #endif

        vec3 skyColorSqrt = sqrt(skyColor);
        // Doing these things because vanilla skyColor gets to 0 during a thunderstorm
        float invRainStrength2 = (1.0 - rainStrength) * (1.0 - rainStrength);
        vec3 skyColorM = mix(max(skyColorSqrt, vec3(0.63, 0.67, 0.73)), skyColorSqrt, invRainStrength2);
        vec3 skyColorM2 = mix(max(skyColor, sunFactor * vec3(0.265, 0.295, 0.35)), skyColor, invRainStrength2);

        #ifdef SPECIAL_BIOME_WEATHER
            vec3 nmscSnowM = inSnowy * vec3(-0.1, 0.3, 0.6);
            vec3 nmscDryM = inDry * vec3(-0.1, -0.2, -0.3);
            vec3 ndscSnowM = inSnowy * vec3(-0.25, -0.01, 0.25);
            vec3 ndscDryM = inDry * vec3(-0.05, -0.09, -0.1);
        #else
            vec3 nmscSnowM = vec3(0.0), nmscDryM = vec3(0.0), ndscSnowM = vec3(0.0), ndscDryM = vec3(0.0);
        #endif
        #if RAIN_STYLE == 2
            vec3 nmscRainMP = vec3(-0.15, 0.025, 0.1);
            vec3 ndscRainMP = vec3(-0.125, -0.005, 0.125);
            #ifdef SPECIAL_BIOME_WEATHER
                vec3 nmscRainM = inRainy * ndscRainMP;
                vec3 ndscRainM = inRainy * ndscRainMP;
            #else
                vec3 nmscRainM = ndscRainMP;
                vec3 ndscRainM = ndscRainMP;
            #endif
        #else
            vec3 nmscRainM = vec3(0.0), ndscRainM = vec3(0.0);
        #endif
        vec3 nuscWeatherM = vec3(0.1, 0.0, 0.1);
        vec3 nmscWeatherM = vec3(-0.1, -0.4, -0.6) + vec3(0.0, 0.06, 0.12) * noonFactor;
        vec3 ndscWeatherM = vec3(-0.15, -0.3, -0.42) + vec3(0.0, 0.02, 0.08) * noonFactor;

        vec3 noonUpSkyColorP    = pow(skyColorM, vec3(2.9)) * (vec3(0.85, 0.92, 0.81) + rainFactor * nuscWeatherM);
        vec3 noonUpSkyColor     = max(mix(noonUpSkyColorP, dot(noonUpSkyColorP, VV_LUMA) * vec3(0.7777, 1.0170, 1.4956), 0.85 * VV_SKY_K), vec3(0.0));
        vec3 noonMiddleSkyColorP = skyColorM * (vec3(1.4, 1.3, 1.3) + rainFactor * (nmscWeatherM + nmscRainM + nmscSnowM + nmscDryM))
                                + noonUpSkyColor * 0.25;
        vec3 noonMiddleSkyColor = max(mix(noonMiddleSkyColorP, dot(noonMiddleSkyColorP, VV_LUMA) * vec3(0.8828, 1.0090, 1.2612), 0.80 * VV_SKY_K), vec3(0.0));
        vec3 noonDownSkyColorP  = skyColorM * (vec3(0.9) + rainFactor * (ndscWeatherM + ndscRainM + ndscSnowM + ndscDryM))
                                + noonUpSkyColor * 0.25;
        vec3 noonDownSkyColor   = max(mix(noonDownSkyColorP, dot(noonDownSkyColorP, VV_LUMA) * vec3(0.9688, 1.0011, 1.0764), 0.85 * VV_SKY_K), vec3(0.0));

        vec3 sunsetUpSkyColorP    = skyColorM2 * (vec3(0.72, 0.522, 0.47) + vec3(0.1, 0.2, 0.35) * rainFactor2);
        vec3 sunsetUpSkyColor     = max(mix(sunsetUpSkyColorP, dot(sunsetUpSkyColorP, VV_LUMA) * vec3(0.9384, 0.9652, 1.3406), 0.85 * VV_SKY_K), vec3(0.0));
        vec3 sunsetMiddleSkyColorP = skyColorM2 * (vec3(1.8, 1.3, 1.2) + vec3(0.15, 0.25, -0.05) * rainFactor2);
        vec3 sunsetMiddleSkyColor = max(mix(sunsetMiddleSkyColorP, dot(sunsetMiddleSkyColorP, VV_LUMA) * vec3(1.1920, 0.9297, 0.8582), 0.75 * VV_SKY_K), vec3(0.0));
        vec3 sunsetDownSkyColorC  = vec3(1.45, 0.86, 0.5) - vec3(0.8, 0.3, 0.0) * rainFactor;
        vec3 sunsetDownSkyColorP  = max(mix(sunsetDownSkyColorC, dot(sunsetDownSkyColorC, VV_LUMA) * vec3(1.2731, 0.9166, 0.7129), 0.70 * VV_SKY_K), vec3(0.0));
        vec3 sunsetDownSkyColorM  = sunsetDownSkyColorP * 0.5 + 0.25 * sunsetMiddleSkyColor;
        vec3 sunsetDownSkyColor   = max(mix(sunsetDownSkyColorM, dot(sunsetDownSkyColorM, VV_LUMA) * vec3(1.2347, 0.9260, 0.7655), 0.70 * VV_SKY_K), vec3(0.0));

        vec3 dayUpSkyColor     = mix(noonUpSkyColor, sunsetUpSkyColor, invNoonFactor2);
        vec3 dayMiddleSkyColor = mix(noonMiddleSkyColor, sunsetMiddleSkyColor, invNoonFactor2);
        vec3 dayDownSkyColor   = mix(noonDownSkyColor, sunsetDownSkyColor, invNoonFactor2);

        vec3 nightColFactor      = 0.9 * vec3(0.07, 0.14, 0.24) * (1.0 - 0.5 * rainFactor) + skyColor;
        vec3 nightUpSkyColorP    = pow(nightColFactor, vec3(0.90)) * 0.45;
        vec3 nightUpSkyColor     = max(mix(nightUpSkyColorP, dot(nightUpSkyColorP, VV_LUMA) * vec3(0.7451, 1.0503, 1.4094), 0.80 * VV_SKY_K), vec3(0.0));
        vec3 nightMiddleSkyColor = sqrt(nightUpSkyColor) * 0.65;
        vec3 nightDownSkyColor   = nightMiddleSkyColor * vec3(0.82, 0.82, 0.88);
    #endif

#endif //INCLUDE_SKY_COLORS
