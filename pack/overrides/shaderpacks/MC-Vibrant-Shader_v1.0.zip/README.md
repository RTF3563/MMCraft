# MC-Vibrant-Shader

**Complementary Reimagined** 셰이더와 **마인크래프트 베드락 에디션의 '선명한 비주얼'(Vibrant Visuals)** 을 섞어서 만든 자바 에디션용 셰이더팩입니다.
선명한 비주얼의 색감·하늘·안개·물을 기본으로 하고, Complementary의 렌더링(그림자, 조명, 반사, 빛줄기)을 바탕에 섞었습니다.

> ⚠️ **AI 사용 안내** — 이 팩의 코드 수정은 AI(Anthropic의 **Claude**)를 사용해 만들었습니다.
> 제작자가 방향을 정하고, 게임에서 직접 확인하면서 수정을 요청하고, 최종 옵션 값을 직접 조정했습니다.

> ℹ️ 비공식 개조 팩입니다. 이 팩에 대한 문의는 Complementary 개발자에게 하지 말아주세요.

---

## 특징

| 기능 | 내용 |
|---|---|
| **선명한 비주얼 톤 매핑** | 베드락 기본 color grading 값(대비 1.15, 채도 1.05, "generic" 톤 매핑)을 재현. 아주 밝은 태양은 하얗게, 횃불·용암은 따뜻한 색을 유지 |
| **해·달 색** | 베드락 기본 조명 값의 시간대별 해 색(정오 따뜻한 흰색 → 오후 주황 → 일몰 진한 주황 → 황혼 분홍)과 푸른 달빛 |
| **하늘 팔레트** | 회청색 천정, 회백색 지평선, 복숭앗빛 노을과 반대쪽 라벤더빛, 회청색 밤 |
| **볼류메트릭 안개·빛내림** | 해 쪽으로 강하게 산란하는 안개(헤니-그린스타인 g = 0.6), 한낮에도 보이는 빛내림 |
| **선명한 비주얼 물** | 베드락 물 재질을 분석해서 재현: 물 텍스처의 각 픽셀이 작은 거울처럼 노멀·거칠기·반사율을 가짐 → 픽셀 줄무늬 반사, 물리 기반 프레넬 합성(가까이는 투명, 멀리는 거울), 픽셀 굴절 |
| **구름** | 반투명하고, 해 쪽은 빛나고, 아랫면은 어두운 바닐라 구름 |
| **하늘빛 그늘** | 그늘이 하늘의 회청색을 띰 |
| **눈부심 조절** | 태양 밝기·용암 밝기 슬라이더 |
| **선명한 비주얼 비율** | 슬라이더 하나로 선명한 비주얼 ↔ Complementary 비율 조절 (기본 80%) |
| **성능** | 성능 기본값 = Complementary '중간' 프로필, 쓰지 않는 계산 제거 |

모든 새 옵션은 셰이더 설정 첫 화면의 **'선명한 비주얼 설정'** 메뉴에 있습니다. 한국어와 영어 메뉴를 지원합니다.

## 설치

1. **[Releases](../../releases)** 에서 `MC-Vibrant-Shader_v1.0.zip`을 내려받습니다.
   (GitHub의 "Code → Download ZIP"은 폴더가 한 단계 더 생겨서 바로 인식되지 않습니다.)
2. 압축을 풀지 말고 `.minecraft/shaderpacks` 폴더에 넣습니다.
3. 게임에서 비디오 설정 → 셰이더 팩에서 선택합니다.

- **지원:** 마인크래프트 자바 에디션 1.20 ~ 최신, **Iris 권장** (OptiFine도 지원)
- 프레임이 부족하면 성능 설정에서 빛줄기 품질이나 그림자 거리를 낮추세요.

## 기본 설정

- 선명한 비주얼 비율 80% · 태양 밝기 60% · 용암 밝기 50%
- 깊은 파랑 100% · 스마트 채도 20% · 물 색상 R50 / G75 / B150 · 물 스타일 "Reimagined + Waves"
- 성능: Complementary '중간' (그림자 거리 128, 빛줄기 낮음, 블록 반사 낮음, 블룸 끔, FXAA 끔)
- 픽셀 그림자·픽셀 블록광, 흔들림 효과 끔, 바닐라 구름

## 검증

배포 전에 다음을 확인했습니다.
- Iris(1.20.1 / 1.21.11 / 26.2) 환경을 흉내 낸 GLSL 검사에서 192개 프로그램 모두 컴파일 성공, 원본 Complementary 대비 새 오류 0건
- 실제 OpenGL 드라이버(Mesa)로 컴파일
- 여러 옵션 조합 컴파일 확인
- 검사 도구는 [`tools/`](tools) 폴더에 있습니다.

## 출처와 크레딧

- **원본 팩:** Complementary Reimagined r5.9.3 — EminGT / Complementary Development — https://www.complementary.dev
  (Complementary 크레딧: Capt Tatsu의 BSL Shaders 등, 게임 안 '정보' 메뉴 참고)
- **선명한 비주얼 기준값:** Mojang이 공개한 [bedrock-samples](https://github.com/Mojang/bedrock-samples) 저장소의 설정 값(color_grading, lighting, atmospherics, fogs, water, 물 텍스처 세트)을 측정해서 맞췄습니다. **Mojang의 텍스처나 파일은 이 팩에 포함되어 있지 않습니다.**
- **코드 작성:** AI(Anthropic의 Claude)
- 마인크래프트와 '선명한 비주얼(Vibrant Visuals)'은 Mojang Studios / Microsoft의 상표입니다. 이 팩은 Mojang, Microsoft, Complementary Development와 관련이 없습니다.

## 라이선스

이 팩에는 원본 팩의 **Complementary License Agreement 1.7**([License.txt](License.txt))이 그대로 적용됩니다. 다른 라이선스는 추가하지 않았습니다.

이 저장소는 개인 보관용(비공개)입니다. 공개 배포하려면 먼저 License.txt 1.3항의 재배포 조건(이름, 사람이 직접 작성한 코드 등)을 확인하세요.

---

## English

**MC-Vibrant-Shader** is a Java Edition shader pack that mixes **Complementary Reimagined** (by EminGT) with the look of **Minecraft Bedrock Edition's Vibrant Visuals**. Vibrant Visuals colors, sky, fog and water come first; Complementary's rendering (shadows, lighting, reflections, light shafts) is mixed in underneath.

- **AI disclosure:** the code changes in this pack were written with AI (**Claude by Anthropic**). The author set the direction, tested in game, requested fixes and tuned the final option values.
- Vibrant Visuals reference values were measured from Mojang's public bedrock-samples repository (tone mapping "generic" with contrast 1.15 / saturation 1.05, sun & moon color keyframes, sky palette, Henyey-Greenstein g = 0.6 fog scattering, and the water texture set: normals from the texture slope, roughness = −0.396 + 0.748 × brightness, F0 ≈ 0.05). No Mojang assets are included.
- **Install:** download the zip from Releases, put it (zipped) into `.minecraft/shaderpacks`. Minecraft Java 1.20 – latest, Iris recommended (OptiFine supported).
- Private archive. Before any public release, check the redistribution terms in License.txt section 1.3.
- Unofficial modification: please don't ask the Complementary developers for support. Based on Complementary Reimagined r5.9.3 — https://www.complementary.dev — licensed under the Complementary License Agreement 1.7 (License.txt).
